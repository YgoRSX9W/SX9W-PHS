#Copyright (C) 2021 YgoR-SX9W
RED="$(printf '\033[31m')"  
GREEN="$(printf '\033[32m')"  
ORANGE="$(printf '\033[33m')"  
BLUE="$(printf '\033[34m')"
MAGENTA="$(printf '\033[35m')"  
CYAN="$(printf '\033[36m')"  
WHITE="$(printf '\033[37m')" 
BLACK="$(printf '\033[30m')"
REDBG="$(printf '\033[41m')"  
GREENBG="$(printf '\033[42m')"  
ORANGEBG="$(printf '\033[43m')"  
BLUEBG="$(printf '\033[44m')"
MAGENTABG="$(printf '\033[45m')"  
CYANBG="$(printf '\033[46m')"  
WHITEBG="$(printf '\033[47m')" 
BLACKBG="$(printf '\033[40m')"
RESETBG="$(printf '\e[0m\n')"
clear
info() {
clear
	{ clear; echo; }
	cat <<- EOF
	${RED} ░ █░░${WHITE}▒█ ${RED}█▀▀█ █▀▀▀█ ${WHITE}█▀▀█  ${WHITE} ░░   █▀▀▀█ ${GREEN}▀▄▒${WHITE}▄▀ ${GREEN}▄▀▀▄ ${WHITE}█░░${GREEN}▒█░
${WHITE} ░ █▄▄${RED}▄█ ${WHITE}█░▄▄ █░░${RED}▒█ █▄▄▀   ${WHITE}▀▀  ${GREEN} ▀▀▀▄▄ ${GREEN}░▒█░░ ${WHITE}▀▄▄█ ${WHITE}█▒█▒█░
${RED} ░ ░▒█${RED}░░ █▄▄█ █▄${WHITE}▄▄█ ${RED}█░▒█   ${WHITE}░░   █▄▄▄█ ${GREEN}▄▀▒▀▄ ${WHITE}░▄▄▀ ${GREEN}█▄▀▄█░!


		${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄
     
     ${WHITEBG}${RED}Copyright (C) 2021 YgoR-SX9W${RESETBG}
     ${RED}BLACK HELL TEAM
     
${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄${RED}▀${WHITE}▄

		${RED}[${WHITE}00${RED}]${WHITE} Voutar     ${RED}[${WHITE}99${RED}]${WHITE} Sair

	EOF
	read -p "${RED}[${WHITE}-${RED}]${RED} Selecione uma opção ${WHITE}≫ : ${BLUE}"

	if [[ "$REPLY" == 99 ]]; then
		exit
	elif [[ "$REPLY" == 0 || "$REPLY" == 00 ]]; then
		echo -ne "\n${GREEN}[${WHITE}+${GREEN}]${CYAN} Voltando ao menu principal..."
		{ sleep 1; menu;}
	else
		echo -ne "\n${RED}[${WHITE}!${RED}]${RED} Opção inválida, tente novamente..."
		{ sleep 1; info; }
	fi
}
menu() {
clear
	cat <<- EOF
${RED} ░ █░░${WHITE}▒█ ${RED}█▀▀█ █▀▀▀█ ${WHITE}█▀▀█  ${WHITE} ░░   █▀▀▀█ ${GREEN}▀▄▒${WHITE}▄▀ ${GREEN}▄▀▀▄ ${WHITE}█░░${GREEN}▒█░
${RED} ░ █▄▄▄█ ${WHITE}█░▄▄ █░░${RED}▒█ █▄▄▀   ${WHITE}▀▀  ${GREEN} ▀▀▀▄▄ ${GREEN}░▒█░░ ${WHITE}▀▄▄█ ${WHITE}█▒█▒█░
${WHITE} ░ ░▒█${RED}░░ █▄▄█ █▄${WHITE}▄▄█ ${RED}█░▒█   ${WHITE}░░   █▄▄▄█ ${GREEN}▄▀▒▀▄ ${WHITE}░▄▄▀ ${GREEN}█▄▀▄█░

	

${RED}[${WHITE}01${RED}]${WHITE} MENU 
${RED}[${WHITE}02${RED}]${WHITE} Info
${RED}[${WHITE}03${RED}]${WHITE} Sair
          
	EOF

	read -p "${RED}[${WHITE}-${RED}]${WHITE} Selecione uma opção ${RED}>> ${BLUE}"

	if [[ "$REPLY" == 3 || "$REPLY" == 03 ]]; then
		exit
	elif [[ "$REPLY" == 1 || "$REPLY" == 01 ]]; then
		bash SX9W-PHS3.sh
	elif [[ "$REPLY" == 2 || "$REPLY" == 02 ]]; then
		clear 
		info
	else
		echo -ne "\n${RED}[${WHITE}!${RED}]${RED} Opção invalida ,Escolha  outra  . . ."
		{clear; menu}
	fi
}
menu